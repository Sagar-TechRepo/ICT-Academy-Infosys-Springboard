package com.mycom.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.mycom.bean.Country;

public class CountryService {
	static HashMap<Integer, Country> countryIdMap = getCountryIdMap();

	public CountryService() {
		super();
		// Add some countries data
		if (countryIdMap == null) {
			countryIdMap = new HashMap<Integer, Country>();
			
			
			// Creating some objects of Country while initializing
			Country india = new Country(1, "India");
			Country singapore = new Country(2, "Singapore");
			Country uk = new Country(3, "UK");
			Country us = new Country(4, "US");
			Country france = new Country(5, "France");

			countryIdMap.put(1, india);
			countryIdMap.put(2, singapore);
			countryIdMap.put(3, uk);
			countryIdMap.put(4, us);
			countryIdMap.put(5, france);
			
		}
	}

	public List<Country> getAllCountries() {// GET method of HTTP
		List<Country> countries = 
				new ArrayList<Country>(countryIdMap.values());//retrieve all country details
		return countries;
	}

	public Country getCountry(int id) { // GET method of HTTP 
		Country country = countryIdMap.get(id);
		return country;
	}


	// Utility method to get max id
	public static int getMaxId() {
		int max = 0;
		for (int id : countryIdMap.keySet()) {
			if (max <= id)
				max = id;
	}
		return max;
	}
	public Country addCountry(Country country) {// POST method of HTTP
		//Get the maximum id and add 1 to it
		country.setId( getMaxId() + 1);
		countryIdMap.put(country.getId(), country);// put() is to add objects to country map
		return country;
	}

	
	public Country updateCountry(Country country) { // PUT mehod of HTTP
		if (country.getId() <= 0)
			return null;
		countryIdMap.put(country.getId(), country);
		return country;

	}

	public void deleteCountry(int id) {  // DELETE method of HTTP
		countryIdMap.remove(id);
	}

	public static HashMap<Integer, Country> getCountryIdMap() {
		return countryIdMap;
	}

}
